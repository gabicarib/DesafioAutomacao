

package steps;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;

import pages.HomePage;
import pages.LoginPage;
import utils.Generator;
import utils.Screenshot;
import utils.Web;

public class Steps {
private WebDriver navegador;
	/**
	 * M�todo respons�vel por fazer o setup da execu��o dos testes e iniciar a inst�ncia das pages
	 */

	@Before
	public void setUp() {

		navegador = Web.abrirBrowser();
	}
	@Test
	public void validacoesLogin (){
		new LoginPage(navegador)
				.fazerLogin("gabriela.carvalho", "gabi12345")
				.Issues()
				.Report()
				.Projeto()
				.formulario("Web", "Teste1", "Teste2", "TesteDeSoftware", "Testar o Software");







	}


	//@After
	//public void tearDown() {
	//	navegador.quit();
	}
//}
