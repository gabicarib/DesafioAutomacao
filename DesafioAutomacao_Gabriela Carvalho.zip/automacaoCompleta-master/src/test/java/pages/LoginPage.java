

package pages;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;


public class LoginPage {

	private WebDriver navegador;

	public LoginPage(WebDriver navegador) {
		this.navegador = navegador;
}


public HomePage fazerLogin(String Login, String password) {
	navegador.findElement(By.name("username")).sendKeys(Login);
	navegador.findElement(By.name("password")).sendKeys(password);
	navegador.findElement(By.className("button")).click();
	return new HomePage(navegador);

}
}


