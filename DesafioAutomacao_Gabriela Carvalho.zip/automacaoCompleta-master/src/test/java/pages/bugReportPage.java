package pages;

import net.bytebuddy.asm.Advice;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class bugReportPage {
    private WebDriver navegador;

    public bugReportPage  (WebDriver navegador) {
        this.navegador = navegador;
}
    public bugReportPage formulario(String Plataforma, String OS, String OsVersao, String sumario, String descricao) {

        WebElement campoCategoria = navegador.findElement(By.name("category_id"));
        new Select(campoCategoria).selectByValue("65");
        WebElement campoReprodutibilidade = navegador.findElement(By.name("reproducibility"));
        new Select(campoReprodutibilidade).selectByValue("30");
        WebElement campoGravidade = navegador.findElement(By.name("severity"));
        new Select(campoGravidade).selectByValue("20");
        WebElement campoPrioridade = navegador.findElement(By.name("priority"));
        new Select(campoPrioridade).selectByValue("40");
        WebElement campoPerfil = navegador.findElement(By.name("profile_id"));
        new Select(campoPerfil).selectByValue("74");
        navegador.findElement(By.id("platform")).sendKeys(Plataforma);
        navegador.findElement(By.id("os")).sendKeys(OS);
        navegador.findElement(By.id("os_build")).sendKeys(OsVersao);
        navegador.findElement(By.name("summary")).sendKeys(sumario);
        navegador.findElement(By.name("description")).sendKeys(descricao);
        navegador.findElement(By.className("button")).click();
        navegador.findElement(By.linkText("Logout")).click();



        return this;
    }





}
