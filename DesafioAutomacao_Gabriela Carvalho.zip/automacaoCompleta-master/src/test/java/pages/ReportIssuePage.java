package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class ReportIssuePage {
    private WebDriver navegador;
    private By.ByClassName driver;

    public ReportIssuePage (WebDriver navegador) {
        this.navegador = navegador;
    }

    public bugReportPage Projeto () {

        WebElement campoProjeto = navegador.findElement(By.name("project_id"));
        new Select(campoProjeto).selectByValue("24");
        navegador.findElement(By.className("button")).click();

        return new bugReportPage(navegador);
    }
}
