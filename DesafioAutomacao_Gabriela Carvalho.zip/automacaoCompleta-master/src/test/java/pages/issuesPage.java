package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class issuesPage {
    private WebDriver navegador;

    public issuesPage (WebDriver navegador) {
        this.navegador = navegador;
    }
    public issuesPage Issues () {
        navegador.findElement(By.linkText("View Issues")).click();

        return this;
}
    public ReportIssuePage Report () {
        navegador.findElement(By.linkText("Report Issue")).click();

        return new ReportIssuePage(navegador);
    }

}
