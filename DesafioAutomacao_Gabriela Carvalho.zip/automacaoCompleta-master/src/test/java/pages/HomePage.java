package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage {
    private WebDriver navegador;

    public HomePage(WebDriver navegador) {
        this.navegador = navegador;

    }
    public issuesPage Issues () {
        navegador.findElement(By.linkText("View Issues")).click();

        return new issuesPage(navegador);
    }
}
