
package utils;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.concurrent.TimeUnit;

public class Web {
	
	/**
	 * M�todo respons�vel para configurar e iniciar a inst�ncia do navegador
	 * @return navegador do tipo WebDriver
	 */
	public static WebDriver abrirBrowser() {
		final String URL = "https://mantis-prova.base2.com.br/login_page.php";
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\gabri\\drivers\\chromedriver.exe");
		WebDriver navegador = new ChromeDriver();
		navegador.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
		navegador.manage().window().maximize();
		navegador.get(URL);
		
		return navegador;
	}
}
